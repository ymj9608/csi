from copy import deepcopy

def strip_pii_external(payload):
    """Remove PII only for external channels. Returns a new dict with PII fields removed."""
    if 'phone' in payload:
        payload = payload.copy()
        payload.pop('phone')
    if 'email' in payload:
        payload = payload.copy()
        payload.pop('email')
    return payload

def build_deliveries(event, failed, routes):
    """Build deliveries for each channel, stripping PII only for external channels."""
    deliveries = []
    for channel in ['r1', 'r2'] if not failed else ['r2', 'r3']:
        payload = deepcopy(event)
        if routes[channel]['boundary'] == 'EXTERNAL':
            payload = strip_pii_external(payload)
        deliveries.append((channel, payload))
    return deliveries