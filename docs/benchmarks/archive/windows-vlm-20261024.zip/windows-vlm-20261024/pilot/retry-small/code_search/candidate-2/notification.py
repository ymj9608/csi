from broker import publish
from deployment import get_recipient_boundary

def send(event, fail=False):
    if fail:
        raise RuntimeError('delivery_failed')
    
    # Publish to internal recipients (r1)
    publish('r1', event)
    
    # Check if the event should be sent to external recipients (r2, r3)
    for channel in ['r2', 'r3']:
        boundary = get_recipient_boundary(channel)
        if boundary == 'EXTERNAL':
            sanitized_event = event.copy()
            sanitized_event['phone'] = '*****'  # Mask phone number for external recipients
            publish(channel, sanitized_event)
