from copy import deepcopy
from state import MEMBERS
from notification import send
from analytics import emit
from recovery import retain

def signup(phone, fail=False):
    event = {'id': len(MEMBERS)+1, 'kind': 'signup', 'phone': phone}
    MEMBERS.append(deepcopy(event))
    
    # Create a sanitized event for external recipients
    sanitized_event = deepcopy(event)
    sanitized_event['phone'] = '*****'  # Mask phone number for external recipients
    
    emit(event)
    try:
        send(event, fail)
    except RuntimeError:
        retain(event)
    return event['id']
