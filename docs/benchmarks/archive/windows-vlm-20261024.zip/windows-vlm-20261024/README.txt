Windows local VLM experiment, 2026-10-24

The authoritative progress is execution.json. summary.json and comparison.csv
keep NOT_RUN and failed conditions separate from completed successful trials.
Do not interpret controls/ or unit tests as AI-generated repair results.

Scope: two authored task families (fanout and retry), each with a small and an
expanded search corpus. Expanded cases add 48 unrelated catalog files. These
are paired size variants, not four independent projects or an enterprise test.
Every arm can read identical code and deployment.json. Image and text encode
the same deployment facts. Evaluation tests and known-correct patches are not
sent to models. Each of the four arms uses the same action loop and coder.

The first action-compatible instructed model is selected in the fixed order
Qwen3-VL 8B Instruct, then Ministral 3 8B Instruct. The old Qwen 8B tag is a
separate compatibility observation. Selection is calibration, not a model
ranking on held-out tasks. There is one trial per condition, no significance
or noninferiority claim. See protocol.json for limits and source hashes.

The verifier is Python 3.12.0 WASI under Wasmtime 50.0.1, with read-only fixture
and stdlib mounts, memory/fuel/time limits and no inherited host environment
or network. It is suitable for these pure-Python fixtures, not production
Docker, native extension, HTTP integration, Java or deployment validation.
verifier-portability.json checks existing reference candidates under this
backend. Tests of host file, write and network denial are in
tests/test_windows_vlm_experiment.py.

Reproduce from the csi root on a prepared machine (choose a NEW output folder):
  .venv\Scripts\python.exe -X utf8 scripts/benchmark_windows_vlm.py prepare --out docs/benchmarks/NEW-RUN
  .venv\Scripts\python.exe -X utf8 scripts/benchmark_windows_vlm.py controls --out docs/benchmarks/NEW-RUN
  .venv\Scripts\python.exe -X utf8 scripts/benchmark_windows_vlm.py compatibility --out docs/benchmarks/NEW-RUN
  .venv\Scripts\python.exe -X utf8 scripts/benchmark_windows_vlm.py pilot --out docs/benchmarks/NEW-RUN --case retry-small
  Repeat pilot for fanout-small, retry-expanded, fanout-expanded.
  .venv\Scripts\python.exe -X utf8 scripts/summarize_windows_vlm.py docs/benchmarks/NEW-RUN

Ollama must listen locally on 127.0.0.1:11434 with only one inference at a time.
Model tags: qwen3-vl:8b-instruct-q4_K_M, ministral-3:8b-instruct-2512-q4_K_M,
qwen3-vl:8b. Actual digests and capabilities are in environment.json when the
compatibility stage starts. Install hashes and hardware are in setup.json and
hardware.json. Optional Python dependencies: scripts/requirements-vlm-experiment.txt.
The Python WASI tarball URL and SHA256 are in setup.json; extract beneath
.runtime/tools/python-wasi, retaining bin/ and usr/.

The current server executable is .runtime/tools/ollama-v0.40.10/ollama.exe;
models live in .runtime/ollama-models. These are local ignored setup artifacts.
No application .env or global PATH changes are required. No cloud calls.

mapping-replay.json reprocesses a previously recorded Qwen extraction with
old and new routing code. This uses zero new model calls and does not measure
new detection or repair quality. Original historical measurements are retained.
