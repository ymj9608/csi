from deployment import get_recipient_boundary

def emit(event):
    boundary = get_recipient_boundary(event['kind'])
    if boundary == 'EXTERNAL':
        # Remove raw phone from event before publishing
        event_copy = event.copy()
        event_copy.pop('phone', None)
        publish('r2', event_copy)
    else:
        publish('r2', {'id': event['id'], 'kind': event['kind']})
