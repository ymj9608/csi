from copy import deepcopy
from state import ARCHIVE
from relay import emit
import json
import os

def retain(event):
    ARCHIVE.append(deepcopy(event))
    with open('deployment.json', 'r') as f:
        deployment = json.load(f)
    
    # Check if the recipient is internal or external
    recipient = event['kind']
    if recipient in deployment:
        boundary = deployment[recipient]['boundary']
        if boundary == 'EXTERNAL':
            # Remove raw phone from event before publishing
            event_copy = event.copy()
            event_copy.pop('phone', None)
            emit(event_copy)
        else:
            emit(event)
    else:
        emit(event)
