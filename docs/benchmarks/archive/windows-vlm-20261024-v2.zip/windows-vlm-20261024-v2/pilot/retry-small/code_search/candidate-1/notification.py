from broker import publish
from deployment import get_recipient_boundary

def send(event, fail=False):
    if fail:
        raise RuntimeError('delivery_failed')
    
    # Create a copy of the event without the phone for external recipients
    event_copy = deepcopy(event)
    event_copy.pop('phone', None)
    
    publish('r1', event)
    
    # Publish to external recipients (r2, r3) with phone stripped
    for recipient in ['r2', 'r3']:
        boundary = get_recipient_boundary(recipient)
        if boundary == 'EXTERNAL':
            publish(recipient, event_copy)
