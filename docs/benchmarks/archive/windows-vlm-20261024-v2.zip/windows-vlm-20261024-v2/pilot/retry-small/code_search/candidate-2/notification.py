from broker import publish
import json
import os

def send(event, fail=False):
    if fail:
        raise RuntimeError('delivery_failed')
    with open('deployment.json', 'r') as f:
        deployment = json.load(f)
    
    # Check if the recipient is internal or external
    recipient = event['kind']
    if recipient in deployment:
        boundary = deployment[recipient]['boundary']
        if boundary == 'EXTERNAL':
            # Remove raw phone from event before publishing
            event_copy = event.copy()
            event_copy.pop('phone', None)
            publish(recipient, event_copy)
        else:
            publish(recipient, event)
    else:
        publish('r1', event)
