from broker import publish

def emit(event):
    # Remove raw phone before external publication
    sanitized_event = {
        'id': event['id'],
        'kind': event['kind']
    }
    publish('r2', sanitized_event)
