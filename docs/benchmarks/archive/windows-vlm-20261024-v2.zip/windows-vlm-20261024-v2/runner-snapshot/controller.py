import ctypes
import json
import sys
import threading
import time
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path.cwd()))
from scripts import benchmark_windows_vlm as run
from scripts.summarize_windows_vlm import summarize

out=Path('docs/benchmarks/windows-vlm-20261024-v2').resolve()
stop=threading.Event()
class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),
              ('total',ctypes.c_ulonglong),('free',ctypes.c_ulonglong),
              ('totalPage',ctypes.c_ulonglong),('freePage',ctypes.c_ulonglong),
              ('totalVirtual',ctypes.c_ulonglong),('freeVirtual',ctypes.c_ulonglong),
              ('reserved',ctypes.c_ulonglong)]
def monitor():
    with (out/'resources.jsonl').open('x',encoding='utf-8') as stream:
        while not stop.is_set():
            memory=Memory(); memory.length=ctypes.sizeof(memory)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory))
            row={'at':datetime.now(timezone.utc).isoformat(),'availableRamBytes':memory.free,'memoryLoadPercent':memory.load}
            try:
                with run.client() as api: row['loadedModels']=api.get('/api/ps',timeout=3).json().get('models',[])
            except Exception as exc: row['monitorError']=type(exc).__name__
            stream.write(json.dumps(row)+'\n'); stream.flush()
            stop.wait(5)
def status(phase, **kwargs):
    run.write(out/'execution.json',{'phase':phase,'at':datetime.now(timezone.utc).isoformat(),**kwargs})
    print(json.dumps({'phase':phase,**kwargs}),flush=True)
thread=threading.Thread(target=monitor,daemon=True);thread.start()
try:
    status('WAITING_FOR_MODELS')
    started=time.monotonic()
    while True:
        with run.client() as api:
            names={m['name'] for m in api.get('/api/tags').json()['models']}
        if set(run.MODELS)<=names: break
        if time.monotonic()-started>5400: raise TimeoutError('Model installation wait limit')
        time.sleep(10)
    status('CALIBRATION_REUSED', source='windows-vlm-20261024')
    run.check_frozen(out)
    rows=json.loads((out/'compatibility.json').read_text(encoding='utf-8'))
    model=next((m for m in run.MODELS[:2] if any(r['model']==m and r['actionPassed'] for r in rows)),None)
    if model is None:
        status('BLOCKED_COMPATIBILITY',reason='Neither instructed model passed the tool-action probe')
    else:
        status('PILOT',model=model)
        for case in ['retry-small','fanout-small','retry-expanded','fanout-expanded']:
            status('PILOT',model=model,case=case)
            run.pilot(out,case,model)
            summarize(out)
        status('COMPLETE',model=model)
except Exception as exc:
    status('FAILED',error=type(exc).__name__+': '+str(exc))
    raise
finally:
    stop.set();thread.join(timeout=5);summarize(out)
