"""Scheduled compatibility export; not connected to the broker routes."""
ENDPOINT = "http://archive-partner.example.invalid/contact-export"


def export_snapshot(db, transport):
    rows = db.execute("SELECT record_id, telephone FROM profile_records").fetchall()
    body = [{"id": row["record_id"], "contact": row["telephone"]} for row in rows]
    transport.post(ENDPOINT, json=body, timeout=10)
    return len(body)
