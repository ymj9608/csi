CREATE TABLE rollup_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    period TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX rollup_records_owner ON rollup_records(owner_ref);
