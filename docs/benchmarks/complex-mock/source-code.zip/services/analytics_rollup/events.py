"""Broker boundary for analytics_rollup; event body is an injected mapping."""
TOPIC = "analytics_rollup.internal"
CONSUMES = ['reward.accrued', 'payment.settled']


def publish(bus, correlation_id, payload):
    envelope = {"id": correlation_id, "type": TOPIC, "body": dict(payload)}
    bus.publish(TOPIC, envelope)
    return envelope


def accept(envelope):
    if envelope.get("type") not in CONSUMES:
        raise ValueError("unsupported event type")
    return dict(envelope["body"])
