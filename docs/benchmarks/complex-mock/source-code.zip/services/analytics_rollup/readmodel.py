"""Owner-scoped read projection for rollup records."""
from services.analytics_rollup.repository import find
from services.analytics_rollup.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "period": row["period"], "version": row["version"]}
