def aggregate(rows):
    totals = {}
    for row in rows:
        key = (row["period"], row["currency"])
        target = totals.setdefault(key, {"count": 0, "amount": 0})
        target["count"] += 1
        target["amount"] += row["amount"]
    return [{"period": key[0], "currency": key[1], **value} for key, value in sorted(totals.items())]


def suppress_small_groups(rollups, minimum=5):
    if minimum < 2:
        raise ValueError("minimum aggregate size must exceed one")
    return [dict(row) for row in rollups if row["count"] >= minimum]
