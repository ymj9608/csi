"""Perform one aggregate reporting transition using injected ports."""
from services.analytics_rollup.policy import authorize
from services.analytics_rollup.repository import save
from services.analytics_rollup.events import publish
from services.analytics_rollup.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("rollup aggregated id=%s", record.record_id)
    return {"id": record.record_id, "status": "aggregated"}
