CREATE TABLE return_case_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    reason TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX return_case_records_owner ON return_case_records(owner_ref);
