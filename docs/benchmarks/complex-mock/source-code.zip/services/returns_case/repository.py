"""Bound-parameter persistence for return_case_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO return_case_records (record_id, owner_ref, reason, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET reason=excluded.reason, version=version+1",
        (record.record_id, record.owner_ref, record.reason, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM return_case_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM return_case_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
