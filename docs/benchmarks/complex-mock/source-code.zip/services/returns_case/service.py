"""Perform one return authorization transition using injected ports."""
from services.returns_case.policy import authorize
from services.returns_case.repository import save
from services.returns_case.events import publish
from services.returns_case.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("return_case authorized id=%s", record.record_id)
    return {"id": record.record_id, "status": "authorized"}
