def eligible(order, now_day, reason):
    if reason not in {"damaged", "wrong_item", "changed_mind"}:
        raise ValueError("unknown return reason")
    if order["status"] != "delivered" or order.get("returned"):
        return False
    window = 30 if reason in {"damaged", "wrong_item"} else 7
    return 0 <= now_day - order["delivery_day"] <= window


def refund_amount(unit_price, returned_units, purchased_units):
    if not 0 < returned_units <= purchased_units:
        raise ValueError("invalid returned quantity")
    return unit_price * returned_units
