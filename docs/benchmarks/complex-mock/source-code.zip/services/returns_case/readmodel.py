"""Owner-scoped read projection for return_case records."""
from services.returns_case.repository import find
from services.returns_case.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "reason": row["reason"], "version": row["version"]}
