CREATE TABLE product_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    sku TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX product_records_owner ON product_records(owner_ref);
