from decimal import Decimal, ROUND_HALF_UP


def quoted_price(base, discount_rate):
    base, discount_rate = Decimal(str(base)), Decimal(str(discount_rate))
    if base < 0 or not 0 <= discount_rate <= 1:
        raise ValueError("invalid price")
    return (base * (1 - discount_rate)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def publishable(product):
    required = ("sku", "title", "category")
    return all(product.get(key) for key in required) and product.get("price", -1) >= 0


def visible_variants(variants):
    return sorted((item for item in variants if item["active"]), key=lambda item: item["sku"])
