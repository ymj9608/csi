"""Owner-scoped read projection for product records."""
from services.product_catalog.repository import find
from services.product_catalog.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "sku": row["sku"], "version": row["version"]}
