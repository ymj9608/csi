"""Perform one product publication transition using injected ports."""
from services.product_catalog.policy import authorize
from services.product_catalog.repository import save
from services.product_catalog.events import publish
from services.product_catalog.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("product published id=%s", record.record_id)
    return {"id": record.record_id, "status": "published"}
