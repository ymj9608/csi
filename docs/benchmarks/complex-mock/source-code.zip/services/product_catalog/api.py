"""HTTP adapter contract for product publication; no server is started."""
from services.product_catalog.service import execute
from services.product_catalog.readmodel import detail


def post(body, actor, ports):
    result = execute(body, actor, ports.db, ports.bus, ports.logger)
    return 202, result


def get(record_id, actor, ports):
    result = detail(ports.db, actor, record_id)
    return (200, result) if result is not None else (404, {"error": "not_found"})
