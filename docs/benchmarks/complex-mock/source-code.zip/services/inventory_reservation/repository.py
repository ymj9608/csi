"""Bound-parameter persistence for reservation_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO reservation_records (record_id, owner_ref, warehouse, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET warehouse=excluded.warehouse, version=version+1",
        (record.record_id, record.owner_ref, record.warehouse, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM reservation_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM reservation_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
