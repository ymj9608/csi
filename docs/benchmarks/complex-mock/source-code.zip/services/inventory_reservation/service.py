"""Perform one stock reservation transition using injected ports."""
from services.inventory_reservation.policy import authorize
from services.inventory_reservation.repository import save
from services.inventory_reservation.events import publish
from services.inventory_reservation.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("reservation reserved id=%s", record.record_id)
    return {"id": record.record_id, "status": "reserved"}
