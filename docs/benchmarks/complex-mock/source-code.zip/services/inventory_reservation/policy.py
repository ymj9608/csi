"""Authorization rules for reserve_stock; not a legal compliance decision."""
ACTION = "reserve_stock"


def authorize(actor, owner_ref):
    if not actor or ACTION not in actor.get("scopes", ()):
        raise PermissionError("missing reserve_stock scope")
    if actor.get("subject") != owner_ref and "operator" not in actor.get("roles", ()):
        raise PermissionError("owner mismatch")


def may_retry(attempts, transient):
    return transient and 0 <= attempts < 3
