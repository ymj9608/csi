"""Owner-scoped read projection for reservation records."""
from services.inventory_reservation.repository import find
from services.inventory_reservation.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "warehouse": row["warehouse"], "version": row["version"]}
