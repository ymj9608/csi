CREATE TABLE reservation_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    warehouse TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX reservation_records_owner ON reservation_records(owner_ref);
