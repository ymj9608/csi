def allocate(bins, quantity):
    if quantity <= 0:
        raise ValueError("quantity must be positive")
    if sum(item["available"] for item in bins) < quantity:
        raise ValueError("insufficient stock")
    result, remaining = [], quantity
    for item in sorted(bins, key=lambda row: row["received_at"]):
        units = min(remaining, item["available"])
        if units:
            result.append({"bin_id": item["id"], "units": units})
            remaining -= units
        if remaining == 0:
            break
    return result


def release(reservation, now):
    return reservation["state"] == "held" and reservation["expires_at"] <= now
