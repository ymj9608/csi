def assign_queue(ticket):
    if ticket["category"] == "payment":
        return "billing_specialists"
    if ticket["category"] in {"shipment", "return"}:
        return "fulfillment_support"
    return "general_support"


def sla_deadline(created_hour, priority):
    targets = {"low": 72, "normal": 24, "urgent": 2}
    if priority not in targets:
        raise ValueError("unknown priority")
    return created_hour + targets[priority]


def overdue(tickets, now_hour):
    return [item["id"] for item in tickets if item["state"] != "closed"
            and sla_deadline(item["created_hour"], item["priority"]) < now_hour]
