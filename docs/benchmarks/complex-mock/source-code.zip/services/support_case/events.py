"""Broker boundary for support_case; event body is an injected mapping."""
TOPIC = "ticket.assigned"
CONSUMES = []


def publish(bus, correlation_id, payload):
    envelope = {"id": correlation_id, "type": TOPIC, "body": dict(payload)}
    bus.publish(TOPIC, envelope)
    return envelope


def accept(envelope):
    if envelope.get("type") not in CONSUMES:
        raise ValueError("unsupported event type")
    return dict(envelope["body"])
