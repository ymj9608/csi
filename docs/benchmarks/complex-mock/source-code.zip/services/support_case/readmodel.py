"""Owner-scoped read projection for ticket records."""
from services.support_case.repository import find
from services.support_case.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "priority": row["priority"], "version": row["version"]}
