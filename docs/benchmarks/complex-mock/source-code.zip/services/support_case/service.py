"""Perform one support assignment transition using injected ports."""
from services.support_case.policy import authorize
from services.support_case.repository import save
from services.support_case.events import publish
from services.support_case.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("ticket assigned id=%s", record.record_id)
    return {"id": record.record_id, "status": "assigned"}
