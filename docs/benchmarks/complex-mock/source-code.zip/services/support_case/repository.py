"""Bound-parameter persistence for ticket_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO ticket_records (record_id, owner_ref, priority, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET priority=excluded.priority, version=version+1",
        (record.record_id, record.owner_ref, record.priority, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM ticket_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM ticket_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
