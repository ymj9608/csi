CREATE TABLE ticket_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    priority TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX ticket_records_owner ON ticket_records(owner_ref);
