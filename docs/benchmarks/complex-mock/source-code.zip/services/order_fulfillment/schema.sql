CREATE TABLE order_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    fulfillment TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX order_records_owner ON order_records(owner_ref);
