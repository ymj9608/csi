"""Bound-parameter persistence for order_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO order_records (record_id, owner_ref, fulfillment, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET fulfillment=excluded.fulfillment, version=version+1",
        (record.record_id, record.owner_ref, record.fulfillment, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM order_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM order_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
