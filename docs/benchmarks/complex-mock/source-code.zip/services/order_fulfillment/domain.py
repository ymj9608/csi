def total_units(lines):
    if not lines or any(line["quantity"] <= 0 for line in lines):
        raise ValueError("invalid order lines")
    return sum(line["quantity"] for line in lines)


def advance(current, event):
    transitions = {("new", "reserve"): "reserved", ("reserved", "pay"): "paid",
                   ("paid", "ship"): "shipped", ("new", "cancel"): "cancelled",
                   ("reserved", "cancel"): "cancelled"}
    if (current, event) not in transitions:
        raise ValueError("invalid order transition")
    return transitions[(current, event)]


def shipment_groups(lines):
    groups = {}
    for line in lines:
        groups.setdefault(line["warehouse"], []).append(dict(line))
    return groups
