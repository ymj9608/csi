"""Owner-scoped read projection for order records."""
from services.order_fulfillment.repository import find
from services.order_fulfillment.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "fulfillment": row["fulfillment"], "version": row["version"]}
