"""Perform one order orchestration transition using injected ports."""
from services.order_fulfillment.policy import authorize
from services.order_fulfillment.repository import save
from services.order_fulfillment.events import publish
from services.order_fulfillment.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("order accepted id=%s", record.record_id)
    return {"id": record.record_id, "status": "accepted"}
