"""Owner-scoped read projection for session records."""
from services.identity_access.repository import find
from services.identity_access.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "scope": row["scope"], "version": row["version"]}
