"""Perform one identity and sessions transition using injected ports."""
from services.identity_access.policy import authorize
from services.identity_access.repository import save
from services.identity_access.events import publish
from services.identity_access.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("session authenticated id=%s", record.record_id)
    return {"id": record.record_id, "status": "authenticated"}
