CREATE TABLE session_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    scope TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX session_records_owner ON session_records(owner_ref);
