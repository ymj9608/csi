import hmac


def effective_scopes(requested, assigned, suspended=False):
    if suspended:
        return frozenset()
    return frozenset(requested).intersection(assigned)


def valid_session(stored, presented_token_digest, now):
    if stored is None or stored["revoked"] or stored["expires_at"] <= now:
        return False
    return hmac.compare_digest(stored["token_digest"], presented_token_digest)


def revoke_owner_sessions(sessions, owner_ref):
    return [dict(session, revoked=True) if session["owner_ref"] == owner_ref else dict(session)
            for session in sessions]
