"""Bound-parameter persistence for audit_event_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO audit_event_records (record_id, owner_ref, event_kind, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET event_kind=excluded.event_kind, version=version+1",
        (record.record_id, record.owner_ref, record.event_kind, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM audit_event_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM audit_event_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
