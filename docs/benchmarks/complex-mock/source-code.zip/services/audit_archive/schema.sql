CREATE TABLE audit_event_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    event_kind TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX audit_event_records_owner ON audit_event_records(owner_ref);
