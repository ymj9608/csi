"""Validate audit_event input without performing network I/O."""
from services.audit_archive.models import Record


def parse_record(body):
    value = body.get("event_kind", "")
    if not isinstance(value, str) or not (len(value) <= 64):
        raise ValueError("event kind is required")
    if not isinstance(body.get("record_id"), str) or not body["record_id"]:
        raise ValueError("record_id is required")
    if not isinstance(body.get("owner_ref"), str) or not body["owner_ref"]:
        raise ValueError("owner_ref is required")
    return Record(body["record_id"], body["owner_ref"], value)
