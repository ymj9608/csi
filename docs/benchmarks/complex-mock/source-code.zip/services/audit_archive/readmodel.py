"""Owner-scoped read projection for audit_event records."""
from services.audit_archive.repository import find
from services.audit_archive.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "event_kind": row["event_kind"], "version": row["version"]}
