def partition_for(event):
    date = event["occurred_on"]
    if len(date) != 10 or date[4] != "-" or date[7] != "-":
        raise ValueError("expected ISO date")
    return date[:7]


def expire_partitions(partitions, cutoff_month, legal_holds):
    return sorted(name for name in partitions if name < cutoff_month and name not in legal_holds)


def event_projection(event):
    allowed = ("event_id", "event_kind", "occurred_on", "status")
    return {key: event[key] for key in allowed if key in event}
