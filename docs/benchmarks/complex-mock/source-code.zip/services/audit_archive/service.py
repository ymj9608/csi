"""Perform one event retention transition using injected ports."""
from services.audit_archive.policy import authorize
from services.audit_archive.repository import save
from services.audit_archive.events import publish
from services.audit_archive.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("audit_event archived id=%s", record.record_id)
    return {"id": record.record_id, "status": "archived"}
