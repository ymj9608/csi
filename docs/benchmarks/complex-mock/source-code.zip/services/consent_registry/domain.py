def permitted(events, owner_ref, purpose, now):
    matching = [event for event in events if event["owner_ref"] == owner_ref
                and event["purpose"] == purpose and event["recorded_at"] <= now]
    if not matching:
        return False
    latest = max(matching, key=lambda event: (event["recorded_at"], event["sequence"]))
    return latest["decision"] == "granted" and latest["expires_at"] > now


def append_decision(events, event):
    if event["decision"] not in {"granted", "revoked"}:
        raise ValueError("unknown consent decision")
    if any(previous["event_id"] == event["event_id"] for previous in events):
        return list(events)
    return [*events, dict(event)]
