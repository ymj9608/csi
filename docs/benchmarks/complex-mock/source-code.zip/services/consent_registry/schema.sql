CREATE TABLE consent_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    purpose TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX consent_records_owner ON consent_records(owner_ref);
