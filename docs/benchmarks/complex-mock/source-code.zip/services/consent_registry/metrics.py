"""Low-cardinality operational metrics for consent_registry."""
SERVICE = "consent_registry"
ALLOWED_STATES = ("recorded", "rejected", "retry")


def report(sink, state, elapsed_ms):
    if state not in ALLOWED_STATES or elapsed_ms < 0:
        raise ValueError("invalid metric")
    sink.increment("operations", service=SERVICE, state=state)
    sink.observe("duration_ms", elapsed_ms, service=SERVICE)
