"""Owner-scoped read projection for consent records."""
from services.consent_registry.repository import find
from services.consent_registry.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "purpose": row["purpose"], "version": row["version"]}
