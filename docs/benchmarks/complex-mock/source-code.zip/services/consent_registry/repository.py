"""Bound-parameter persistence for consent_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO consent_records (record_id, owner_ref, purpose, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET purpose=excluded.purpose, version=version+1",
        (record.record_id, record.owner_ref, record.purpose, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM consent_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM consent_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
