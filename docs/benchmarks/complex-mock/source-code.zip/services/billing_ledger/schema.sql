CREATE TABLE invoice_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    currency TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX invoice_records_owner ON invoice_records(owner_ref);
