"""Perform one invoice accounting transition using injected ports."""
from services.billing_ledger.policy import authorize
from services.billing_ledger.repository import save
from services.billing_ledger.events import publish
from services.billing_ledger.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("invoice posted id=%s", record.record_id)
    return {"id": record.record_id, "status": "posted"}
