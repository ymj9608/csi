from decimal import Decimal, ROUND_HALF_UP


def invoice_totals(lines, tax_rate):
    rate = Decimal(str(tax_rate))
    if not 0 <= rate <= 1:
        raise ValueError("invalid tax rate")
    subtotal = sum((Decimal(str(line["unit_price"])) * line["quantity"] for line in lines), Decimal(0))
    if subtotal < 0:
        raise ValueError("negative invoice")
    tax = (subtotal * rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return {"subtotal": subtotal, "tax": tax, "total": subtotal + tax}


def balanced(entries):
    return sum(entry["debit"] - entry["credit"] for entry in entries) == 0
