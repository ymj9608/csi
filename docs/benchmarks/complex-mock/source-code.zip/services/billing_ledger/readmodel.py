"""Owner-scoped read projection for invoice records."""
from services.billing_ledger.repository import find
from services.billing_ledger.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "currency": row["currency"], "version": row["version"]}
