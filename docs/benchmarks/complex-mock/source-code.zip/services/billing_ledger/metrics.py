"""Low-cardinality operational metrics for billing_ledger."""
SERVICE = "billing_ledger"
ALLOWED_STATES = ("posted", "rejected", "retry")


def report(sink, state, elapsed_ms):
    if state not in ALLOWED_STATES or elapsed_ms < 0:
        raise ValueError("invalid metric")
    sink.increment("operations", service=SERVICE, state=state)
    sink.observe("duration_ms", elapsed_ms, service=SERVICE)
