"""Bound-parameter persistence for invoice_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO invoice_records (record_id, owner_ref, currency, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET currency=excluded.currency, version=version+1",
        (record.record_id, record.owner_ref, record.currency, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM invoice_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM invoice_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
