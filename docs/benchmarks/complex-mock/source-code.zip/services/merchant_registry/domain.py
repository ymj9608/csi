def missing_documents(business_type, submitted):
    required = {"retail": {"registration", "bank_proof"},
                "wholesale": {"registration", "bank_proof", "trade_permit"},
                "service": {"registration", "bank_proof"}}
    if business_type not in required:
        raise ValueError("unsupported business type")
    return sorted(required[business_type] - set(submitted))


def onboarding_state(record):
    if record.get("suspended"):
        return "suspended"
    return "active" if not missing_documents(record["business_type"], record["documents"]) else "pending"
