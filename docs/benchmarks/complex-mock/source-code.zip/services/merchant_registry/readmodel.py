"""Owner-scoped read projection for merchant records."""
from services.merchant_registry.repository import find
from services.merchant_registry.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "business_type": row["business_type"], "version": row["version"]}
