"""Validate merchant input without performing network I/O."""
from services.merchant_registry.models import Record


def parse_record(body):
    value = body.get("business_type", "")
    if not isinstance(value, str) or not (value in {'retail', 'wholesale', 'service'}):
        raise ValueError("unsupported business type")
    if not isinstance(body.get("record_id"), str) or not body["record_id"]:
        raise ValueError("record_id is required")
    if not isinstance(body.get("owner_ref"), str) or not body["owner_ref"]:
        raise ValueError("owner_ref is required")
    return Record(body["record_id"], body["owner_ref"], value)
