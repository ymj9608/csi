CREATE TABLE merchant_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    business_type TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX merchant_records_owner ON merchant_records(owner_ref);
