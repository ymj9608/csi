"""Perform one merchant onboarding transition using injected ports."""
from services.merchant_registry.policy import authorize
from services.merchant_registry.repository import save
from services.merchant_registry.events import publish
from services.merchant_registry.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("merchant registered id=%s", record.record_id)
    return {"id": record.record_id, "status": "registered"}
