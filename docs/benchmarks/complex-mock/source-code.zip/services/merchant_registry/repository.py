"""Bound-parameter persistence for merchant_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO merchant_records (record_id, owner_ref, business_type, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET business_type=excluded.business_type, version=version+1",
        (record.record_id, record.owner_ref, record.business_type, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM merchant_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM merchant_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
