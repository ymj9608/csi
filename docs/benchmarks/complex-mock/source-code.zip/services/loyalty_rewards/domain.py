def earned_points(paid_units, tier, refunded_units=0):
    multipliers = {"basic": 1, "silver": 2, "gold": 3}
    if tier not in multipliers or not 0 <= refunded_units <= paid_units:
        raise ValueError("invalid reward input")
    return (paid_units - refunded_units) // 100 * multipliers[tier]


def apply_reward(balance, amount, event_id, processed):
    if event_id in processed:
        return balance
    if balance + amount < 0:
        raise ValueError("insufficient reward balance")
    processed.add(event_id)
    return balance + amount
