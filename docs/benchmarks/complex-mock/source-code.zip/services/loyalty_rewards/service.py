"""Perform one reward accrual transition using injected ports."""
from services.loyalty_rewards.policy import authorize
from services.loyalty_rewards.repository import save
from services.loyalty_rewards.events import publish
from services.loyalty_rewards.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("reward accrued id=%s", record.record_id)
    return {"id": record.record_id, "status": "accrued"}
