"""Owner-scoped read projection for reward records."""
from services.loyalty_rewards.repository import find
from services.loyalty_rewards.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "tier": row["tier"], "version": row["version"]}
