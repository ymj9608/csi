CREATE TABLE reward_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    tier TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX reward_records_owner ON reward_records(owner_ref);
