"""Bound-parameter persistence for request_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO request_records (record_id, owner_ref, route_key, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET route_key=excluded.route_key, version=version+1",
        (record.record_id, record.owner_ref, record.route_key, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM request_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM request_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
