from urllib.parse import urlsplit


def select_route(raw_path, method, routes):
    path = urlsplit(raw_path).path
    if ".." in path.split("/") or method not in {"GET", "POST", "PUT", "DELETE"}:
        raise ValueError("unsupported request")
    matches = [(prefix, target) for prefix, target in routes.items()
               if path == prefix or path.startswith(prefix + "/")]
    return max(matches, key=lambda entry: len(entry[0]))[1] if matches else None


def admit(bucket, subject, now, capacity=20, window=60):
    previous = [stamp for stamp in bucket.get(subject, []) if now - stamp < window]
    allowed = len(previous) < capacity
    bucket[subject] = previous + ([now] if allowed else [])
    return allowed
