CREATE TABLE request_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    route_key TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX request_records_owner ON request_records(owner_ref);
