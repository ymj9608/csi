"""Perform one request admission transition using injected ports."""
from services.edge_gateway.policy import authorize
from services.edge_gateway.repository import save
from services.edge_gateway.events import publish
from services.edge_gateway.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("request admitted id=%s", record.record_id)
    return {"id": record.record_id, "status": "admitted"}
