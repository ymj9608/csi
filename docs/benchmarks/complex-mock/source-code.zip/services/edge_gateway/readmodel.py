"""Owner-scoped read projection for request records."""
from services.edge_gateway.repository import find
from services.edge_gateway.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "route_key": row["route_key"], "version": row["version"]}
