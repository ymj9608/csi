"""Bounded retry scheduler for request work."""
from services.edge_gateway.policy import may_retry


def retry_failed(queue, handler, limit=20):
    if not 1 <= limit <= 100:
        raise ValueError("invalid batch size")
    completed = 0
    for item in queue.take(limit):
        if not may_retry(item.attempts, item.transient):
            queue.park(item.id, "retry_exhausted")
            continue
        handler(item.payload)
        queue.ack(item.id)
        completed += 1
    return completed
