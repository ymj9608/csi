"""Bound-parameter persistence for settlement_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO settlement_records (record_id, owner_ref, processor, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET processor=excluded.processor, version=version+1",
        (record.record_id, record.owner_ref, record.processor, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM settlement_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM settlement_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
