"""Owner-scoped read projection for settlement records."""
from services.payment_settlement.repository import find
from services.payment_settlement.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "processor": row["processor"], "version": row["version"]}
