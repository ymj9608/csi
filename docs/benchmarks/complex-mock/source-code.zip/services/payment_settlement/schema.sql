CREATE TABLE settlement_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    processor TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX settlement_records_owner ON settlement_records(owner_ref);
