def reconcile(expected, received):
    received_by_id = {item["payment_id"]: item for item in received}
    if len(received_by_id) != len(received):
        raise ValueError("duplicate processor row")
    matched, exceptions = [], []
    for row in expected:
        actual = received_by_id.pop(row["payment_id"], None)
        if actual and actual["amount"] == row["amount"] and actual["currency"] == row["currency"]:
            matched.append(row["payment_id"])
        else:
            exceptions.append({"payment_id": row["payment_id"], "reason": "amount_or_missing"})
    exceptions.extend({"payment_id": key, "reason": "unexpected"} for key in received_by_id)
    return {"matched": matched, "exceptions": exceptions}
