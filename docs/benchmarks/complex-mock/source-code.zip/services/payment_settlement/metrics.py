"""Low-cardinality operational metrics for payment_settlement."""
SERVICE = "payment_settlement"
ALLOWED_STATES = ("reconciled", "rejected", "retry")


def report(sink, state, elapsed_ms):
    if state not in ALLOWED_STATES or elapsed_ms < 0:
        raise ValueError("invalid metric")
    sink.increment("operations", service=SERVICE, state=state)
    sink.observe("duration_ms", elapsed_ms, service=SERVICE)
