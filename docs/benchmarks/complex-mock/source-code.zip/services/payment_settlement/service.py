"""Perform one settlement batches transition using injected ports."""
from services.payment_settlement.policy import authorize
from services.payment_settlement.repository import save
from services.payment_settlement.events import publish
from services.payment_settlement.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("settlement reconciled id=%s", record.record_id)
    return {"id": record.record_id, "status": "reconciled"}
