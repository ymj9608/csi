def contact_patch(existing, incoming, expected_version):
    if existing["version"] != expected_version:
        raise ValueError("stale profile")
    unknown = set(incoming) - {"telephone", "display_name"}
    if unknown:
        raise ValueError("unsupported profile fields")
    updated = dict(existing)
    for key, value in incoming.items():
        if not isinstance(value, str) or not value.strip():
            raise ValueError("empty contact field")
        updated[key] = value.strip()
    updated["version"] += 1
    return updated


def public_projection(record):
    return {key: record[key] for key in ("record_id", "display_name", "version") if key in record}
