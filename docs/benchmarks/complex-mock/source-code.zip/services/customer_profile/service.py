"""Update contact data and publish the durable contact-change record."""
from services.customer_profile.policy import authorize
from services.customer_profile.repository import save
from services.customer_profile.validation import parse_record
from services.customer_profile.events import publish


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    logger.info("profile updated telephone=%s", record.telephone)
    publish(bus, record.record_id, {"destination": record.telephone,
                                   "owner_ref": record.owner_ref, "template": "service_change"})
    return {"id": record.record_id, "status": "updated"}


def record_completion(logger, record_id):
    logger.info("profile update completed id=%s", record_id)
