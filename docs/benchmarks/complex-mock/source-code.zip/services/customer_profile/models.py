"""Domain record for customer contact records."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Record:
    record_id: str
    owner_ref: str
    telephone: str
    version: int = 1

    def as_mapping(self):
        return {"record_id": self.record_id, "owner_ref": self.owner_ref,
                "telephone": self.telephone, "version": self.version}
