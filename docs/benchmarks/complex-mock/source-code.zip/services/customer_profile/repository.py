"""Bound-parameter persistence for profile_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO profile_records (record_id, owner_ref, telephone, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET telephone=excluded.telephone, version=version+1",
        (record.record_id, record.owner_ref, record.telephone, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM profile_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM profile_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
