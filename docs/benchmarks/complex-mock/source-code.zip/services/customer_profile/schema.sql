CREATE TABLE profile_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    telephone TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX profile_records_owner ON profile_records(owner_ref);
