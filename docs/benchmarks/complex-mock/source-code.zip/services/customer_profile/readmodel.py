"""Owner-scoped read projection for profile records."""
from services.customer_profile.repository import find
from services.customer_profile.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "telephone": row["telephone"], "version": row["version"]}
