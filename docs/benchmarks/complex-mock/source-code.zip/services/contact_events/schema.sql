CREATE TABLE envelope_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    event_type TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX envelope_records_owner ON envelope_records(owner_ref);
