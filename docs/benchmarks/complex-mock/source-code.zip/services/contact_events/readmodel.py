"""Owner-scoped read projection for envelope records."""
from services.contact_events.repository import find
from services.contact_events.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "event_type": row["event_type"], "version": row["version"]}
