"""Bound-parameter persistence for envelope_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO envelope_records (record_id, owner_ref, event_type, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET event_type=excluded.event_type, version=version+1",
        (record.record_id, record.owner_ref, record.event_type, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM envelope_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM envelope_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
