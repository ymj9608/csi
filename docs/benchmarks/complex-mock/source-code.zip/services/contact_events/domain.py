def changed_fields(before, after):
    return sorted(key for key in {"telephone", "display_name"} if before.get(key) != after.get(key))


def accept_once(envelope, processed, publish):
    key = (envelope["id"], envelope["type"])
    if key in processed:
        return False
    publish(envelope)
    processed.add(key)
    return True


def validate_sequence(last_version, incoming_version):
    if incoming_version <= last_version:
        return "duplicate"
    return "ready" if incoming_version == last_version + 1 else "gap"
