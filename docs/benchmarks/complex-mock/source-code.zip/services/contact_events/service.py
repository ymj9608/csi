"""Perform one contact change events transition using injected ports."""
from services.contact_events.policy import authorize
from services.contact_events.repository import save
from services.contact_events.events import publish
from services.contact_events.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("envelope published id=%s", record.record_id)
    return {"id": record.record_id, "status": "published"}
