"""HTTP adapter contract for contact change events; no server is started."""
from services.contact_events.service import execute
from services.contact_events.readmodel import detail


def post(body, actor, ports):
    result = execute(body, actor, ports.db, ports.bus, ports.logger)
    return 202, result


def get(record_id, actor, ports):
    result = detail(ports.db, actor, record_id)
    return (200, result) if result is not None else (404, {"error": "not_found"})
