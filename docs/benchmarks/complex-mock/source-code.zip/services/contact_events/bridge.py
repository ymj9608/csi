"""Translate the contact-change contract into a delivery contract."""
from services.contact_events.events import accept, publish


def relay(envelope, bus):
    payload = accept(envelope)
    return publish(bus, envelope["id"], {
        "destination": payload["destination"],
        "template": payload["template"],
        "owner_ref": payload["owner_ref"],
    })
