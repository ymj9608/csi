"""Perform one document lifecycle transition using injected ports."""
from services.document_archive.policy import authorize
from services.document_archive.repository import save
from services.document_archive.events import publish
from services.document_archive.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("document stored id=%s", record.record_id)
    return {"id": record.record_id, "status": "stored"}
