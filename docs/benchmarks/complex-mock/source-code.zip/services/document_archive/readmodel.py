"""Owner-scoped read projection for document records."""
from services.document_archive.repository import find
from services.document_archive.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "retention_class": row["retention_class"], "version": row["version"]}
