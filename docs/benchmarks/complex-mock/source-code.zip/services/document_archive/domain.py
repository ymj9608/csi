import hashlib


def content_digest(content):
    return hashlib.sha256(content).hexdigest()


def deletion_candidates(records, now_day):
    lifetimes = {"short": 30, "standard": 365}
    return [record["id"] for record in records if record["retention_class"] in lifetimes
            and now_day - record["created_day"] > lifetimes[record["retention_class"]]]


def verify_download(content, expected_digest):
    import hmac
    return hmac.compare_digest(content_digest(content), expected_digest)
