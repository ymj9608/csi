CREATE TABLE document_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    retention_class TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX document_records_owner ON document_records(owner_ref);
