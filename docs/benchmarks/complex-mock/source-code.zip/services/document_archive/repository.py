"""Bound-parameter persistence for document_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO document_records (record_id, owner_ref, retention_class, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET retention_class=excluded.retention_class, version=version+1",
        (record.record_id, record.owner_ref, record.retention_class, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM document_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM document_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
