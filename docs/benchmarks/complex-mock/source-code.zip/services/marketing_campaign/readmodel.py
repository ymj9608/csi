"""Owner-scoped read projection for campaign records."""
from services.marketing_campaign.repository import find
from services.marketing_campaign.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "audience": row["audience"], "version": row["version"]}
