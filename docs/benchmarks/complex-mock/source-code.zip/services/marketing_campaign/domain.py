def eligible_audience(records, purpose, now):
    if purpose != "marketing":
        raise ValueError("campaign purpose mismatch")
    return [row["owner_ref"] for row in records if row.get("marketing_consent")
            and row["consent_expires_at"] > now and not row.get("suppressed")]


def allocate_variants(owner_refs, variant_count):
    import hashlib
    if not 1 <= variant_count <= 10:
        raise ValueError("invalid experiment size")
    return {ref: int.from_bytes(hashlib.sha256(ref.encode()).digest()[:4], "big") % variant_count
            for ref in sorted(set(owner_refs))}
