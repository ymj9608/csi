"""Perform one campaign planning transition using injected ports."""
from services.marketing_campaign.policy import authorize
from services.marketing_campaign.repository import save
from services.marketing_campaign.events import publish
from services.marketing_campaign.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("campaign planned id=%s", record.record_id)
    return {"id": record.record_id, "status": "planned"}
