CREATE TABLE campaign_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    audience TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX campaign_records_owner ON campaign_records(owner_ref);
