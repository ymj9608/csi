"""Perform one carrier milestones transition using injected ports."""
from services.shipment_tracking.policy import authorize
from services.shipment_tracking.repository import save
from services.shipment_tracking.events import publish
from services.shipment_tracking.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("shipment tracked id=%s", record.record_id)
    return {"id": record.record_id, "status": "tracked"}
