def apply_milestone(history, incoming):
    if any(item["event_id"] == incoming["event_id"] for item in history):
        return list(history)
    stages = ("packed", "dispatched", "delivered")
    if incoming["milestone"] not in stages:
        raise ValueError("unknown milestone")
    return sorted([*history, dict(incoming)], key=lambda item: item["occurred_at"])


def current_stage(history):
    if not history:
        return "pending"
    stages = {"packed": 1, "dispatched": 2, "delivered": 3}
    return max(history, key=lambda item: stages[item["milestone"]])["milestone"]
