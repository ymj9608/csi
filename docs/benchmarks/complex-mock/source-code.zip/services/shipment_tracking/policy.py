"""Authorization rules for track_shipment; not a legal compliance decision."""
ACTION = "track_shipment"


def authorize(actor, owner_ref):
    if not actor or ACTION not in actor.get("scopes", ()):
        raise PermissionError("missing track_shipment scope")
    if actor.get("subject") != owner_ref and "operator" not in actor.get("roles", ()):
        raise PermissionError("owner mismatch")


def may_retry(attempts, transient):
    return transient and 0 <= attempts < 3
