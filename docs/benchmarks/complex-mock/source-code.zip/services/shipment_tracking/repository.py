"""Bound-parameter persistence for shipment_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO shipment_records (record_id, owner_ref, milestone, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET milestone=excluded.milestone, version=version+1",
        (record.record_id, record.owner_ref, record.milestone, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM shipment_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM shipment_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
