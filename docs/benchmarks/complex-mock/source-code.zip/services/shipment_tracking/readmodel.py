"""Owner-scoped read projection for shipment records."""
from services.shipment_tracking.repository import find
from services.shipment_tracking.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "milestone": row["milestone"], "version": row["version"]}
