CREATE TABLE shipment_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    milestone TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX shipment_records_owner ON shipment_records(owner_ref);
