"""Bound-parameter persistence for index_job_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO index_job_records (record_id, owner_ref, operation, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET operation=excluded.operation, version=version+1",
        (record.record_id, record.owner_ref, record.operation, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM index_job_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM index_job_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
