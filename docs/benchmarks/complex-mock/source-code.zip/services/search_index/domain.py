import re


def tokenize(title):
    return sorted(set(re.findall(r"[a-z0-9]{2,}", title.lower())))


def build_document(product):
    return {"id": product["sku"], "tokens": tokenize(product["title"]),
            "category": product["category"], "active": bool(product["active"])}


def rank(query, documents):
    terms = set(tokenize(query))
    scored = [(len(terms.intersection(document["tokens"])), document["id"])
              for document in documents if document["active"]]
    return [ident for score, ident in sorted(scored, key=lambda row: (-row[0], row[1])) if score]
