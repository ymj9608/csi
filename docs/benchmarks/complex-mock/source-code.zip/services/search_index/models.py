"""Domain record for product search."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Record:
    record_id: str
    owner_ref: str
    operation: str
    version: int = 1

    def as_mapping(self):
        return {"record_id": self.record_id, "owner_ref": self.owner_ref,
                "operation": self.operation, "version": self.version}
