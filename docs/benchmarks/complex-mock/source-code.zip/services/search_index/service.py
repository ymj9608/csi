"""Perform one product search transition using injected ports."""
from services.search_index.policy import authorize
from services.search_index.repository import save
from services.search_index.events import publish
from services.search_index.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("index_job indexed id=%s", record.record_id)
    return {"id": record.record_id, "status": "indexed"}
