CREATE TABLE index_job_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    operation TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX index_job_records_owner ON index_job_records(owner_ref);
