"""Owner-scoped read projection for index_job records."""
from services.search_index.repository import find
from services.search_index.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "operation": row["operation"], "version": row["version"]}
