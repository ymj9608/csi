import hashlib
import hmac


def verify_signature(body, supplied, secret, timestamp, now):
    if abs(now - timestamp) > 300:
        return False
    signed = str(timestamp).encode() + b"." + body
    expected = hmac.new(secret, signed, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, supplied)


def accept_delivery(delivery_id, processed, handler, body):
    if delivery_id in processed:
        return "duplicate"
    handler(body)
    processed.add(delivery_id)
    return "accepted"
