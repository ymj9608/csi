CREATE TABLE callback_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    partner_key TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX callback_records_owner ON callback_records(owner_ref);
