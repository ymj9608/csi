"""Authorization rules for queue_callback; not a legal compliance decision."""
ACTION = "queue_callback"


def authorize(actor, owner_ref):
    if not actor or ACTION not in actor.get("scopes", ()):
        raise PermissionError("missing queue_callback scope")
    if actor.get("subject") != owner_ref and "operator" not in actor.get("roles", ()):
        raise PermissionError("owner mismatch")


def may_retry(attempts, transient):
    return transient and 0 <= attempts < 3
