"""Owner-scoped read projection for callback records."""
from services.partner_webhook.repository import find
from services.partner_webhook.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "partner_key": row["partner_key"], "version": row["version"]}
