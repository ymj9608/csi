"""Perform one partner callbacks transition using injected ports."""
from services.partner_webhook.policy import authorize
from services.partner_webhook.repository import save
from services.partner_webhook.events import publish
from services.partner_webhook.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("callback queued id=%s", record.record_id)
    return {"id": record.record_id, "status": "queued"}
