"""Bound-parameter persistence for callback_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO callback_records (record_id, owner_ref, partner_key, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET partner_key=excluded.partner_key, version=version+1",
        (record.record_id, record.owner_ref, record.partner_key, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM callback_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM callback_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
