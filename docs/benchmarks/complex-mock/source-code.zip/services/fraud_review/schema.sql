CREATE TABLE review_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    decision TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX review_records_owner ON review_records(owner_ref);
