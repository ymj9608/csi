"""Owner-scoped read projection for review records."""
from services.fraud_review.repository import find
from services.fraud_review.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "decision": row["decision"], "version": row["version"]}
