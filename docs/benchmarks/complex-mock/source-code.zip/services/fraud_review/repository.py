"""Bound-parameter persistence for review_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO review_records (record_id, owner_ref, decision, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET decision=excluded.decision, version=version+1",
        (record.record_id, record.owner_ref, record.decision, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM review_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM review_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
