"""Perform one transaction review transition using injected ports."""
from services.fraud_review.policy import authorize
from services.fraud_review.repository import save
from services.fraud_review.events import publish
from services.fraud_review.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("review decided id=%s", record.record_id)
    return {"id": record.record_id, "status": "decided"}
