def assess(transaction, recent_attempts):
    reasons = []
    if transaction["amount"] > 1000000:
        reasons.append("high_value")
    if recent_attempts >= 5:
        reasons.append("velocity")
    if transaction.get("device_changed"):
        reasons.append("new_device")
    return {"decision": "hold" if len(reasons) >= 2 else "allow", "reasons": reasons}


def resolve(review, decision, reviewer):
    if decision not in {"allow", "deny"} or not reviewer:
        raise ValueError("reviewer decision required")
    return dict(review, decision=decision, reviewer=reviewer)
