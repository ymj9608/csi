"""Domain record for delivery scheduling."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Record:
    record_id: str
    owner_ref: str
    channel: str
    version: int = 1

    def as_mapping(self):
        return {"record_id": self.record_id, "owner_ref": self.owner_ref,
                "channel": self.channel, "version": self.version}
