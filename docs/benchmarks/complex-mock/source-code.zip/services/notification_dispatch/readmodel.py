"""Owner-scoped read projection for delivery records."""
from services.notification_dispatch.repository import find
from services.notification_dispatch.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "channel": row["channel"], "version": row["version"]}
