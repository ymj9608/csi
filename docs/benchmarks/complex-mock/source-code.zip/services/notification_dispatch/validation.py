"""Validate delivery input without performing network I/O."""
from services.notification_dispatch.models import Record


def parse_record(body):
    value = body.get("channel", "")
    if not isinstance(value, str) or not (value in {'sms', 'email'}):
        raise ValueError("unsupported channel")
    if not isinstance(body.get("record_id"), str) or not body["record_id"]:
        raise ValueError("record_id is required")
    if not isinstance(body.get("owner_ref"), str) or not body["owner_ref"]:
        raise ValueError("owner_ref is required")
    return Record(body["record_id"], body["owner_ref"], value)
