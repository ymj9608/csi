"""Perform one delivery scheduling transition using injected ports."""
from services.notification_dispatch.policy import authorize
from services.notification_dispatch.repository import save
from services.notification_dispatch.events import publish
from services.notification_dispatch.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("delivery scheduled id=%s", record.record_id)
    return {"id": record.record_id, "status": "scheduled"}
