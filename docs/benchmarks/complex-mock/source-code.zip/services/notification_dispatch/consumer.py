"""Schedule a received delivery request; broker client is injected."""
from services.notification_dispatch.events import accept, publish


def handle(envelope, bus, logger):
    payload = accept(envelope)
    logger.info("dispatch payload=%s", payload)
    return publish(bus, envelope["id"], payload)


def record_outcome(logger, envelope_id, outcome):
    if outcome not in ("accepted", "rejected"):
        raise ValueError("invalid outcome")
    logger.info("dispatch id=%s outcome=%s", envelope_id, outcome)
