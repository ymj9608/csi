"""Bound-parameter persistence for delivery_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO delivery_records (record_id, owner_ref, channel, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET channel=excluded.channel, version=version+1",
        (record.record_id, record.owner_ref, record.channel, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM delivery_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM delivery_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
