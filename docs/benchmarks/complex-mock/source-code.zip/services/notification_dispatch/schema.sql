CREATE TABLE delivery_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    channel TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX delivery_records_owner ON delivery_records(owner_ref);
