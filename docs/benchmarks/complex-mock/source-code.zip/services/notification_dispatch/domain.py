def next_delivery_hour(requested_hour, quiet_start=22, quiet_end=8):
    if not 0 <= requested_hour < 24 or not 0 <= quiet_end < quiet_start < 24:
        raise ValueError("invalid delivery window")
    return quiet_end if requested_hour >= quiet_start or requested_hour < quiet_end else requested_hour


def schedule_batch(requests, already_sent, maximum=100):
    if not 1 <= maximum <= 100:
        raise ValueError("invalid batch size")
    result, seen = [], set(already_sent)
    for request in sorted(requests, key=lambda item: (item["priority"], item["created_at"])):
        if request["id"] not in seen:
            result.append(dict(request))
            seen.add(request["id"])
        if len(result) == maximum:
            break
    return result
