"""Perform one sms provider adapter transition using injected ports."""
from services.sms_gateway.policy import authorize
from services.sms_gateway.repository import save
from services.sms_gateway.events import publish
from services.sms_gateway.validation import parse_record


def execute(body, actor, db, bus, logger):
    record = parse_record(body)
    authorize(actor, record.owner_ref)
    save(db, record)
    publish(bus, record.record_id, {"owner_ref": record.owner_ref})
    logger.info("message submitted id=%s", record.record_id)
    return {"id": record.record_id, "status": "submitted"}
