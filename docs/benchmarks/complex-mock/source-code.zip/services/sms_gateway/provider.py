"""External message adapter; injected transport is never invoked at import."""
ENDPOINT = "http://sms-provider.example.invalid/v1/messages"


def deliver(payload, transport):
    return transport.post(ENDPOINT, json={
        "to": payload["destination"], "template": payload["template"]
    }, timeout=5)


def deliver_private(payload, transport):
    endpoint = "https://sms-provider.example.invalid/v1/messages"
    return transport.post(endpoint, json={
        "to": payload["destination"], "template": payload["template"]
    }, timeout=5, verify=True)
