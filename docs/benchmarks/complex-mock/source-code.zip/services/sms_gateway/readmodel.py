"""Owner-scoped read projection for message records."""
from services.sms_gateway.repository import find
from services.sms_gateway.policy import authorize


def detail(db, actor, record_id):
    row = find(db, record_id)
    if row is None:
        return None
    authorize(actor, row["owner_ref"])
    return {"id": row["record_id"], "template_key": row["template_key"], "version": row["version"]}
