def message_segments(text):
    if not isinstance(text, str) or not text:
        raise ValueError("empty message")
    ascii_only = all(ord(character) < 128 for character in text)
    single, multipart = (160, 153) if ascii_only else (70, 67)
    return 1 if len(text) <= single else (len(text) + multipart - 1) // multipart


def classify_response(status, retry_after=None):
    if 200 <= status < 300:
        return {"state": "accepted", "retry": False}
    if status == 429 or 500 <= status < 600:
        return {"state": "deferred", "retry": True, "delay": min(max(retry_after or 5, 1), 300)}
    return {"state": "rejected", "retry": False}
