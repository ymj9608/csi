CREATE TABLE message_records (
    record_id TEXT PRIMARY KEY,
    owner_ref TEXT NOT NULL,
    template_key TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0)
);
CREATE INDEX message_records_owner ON message_records(owner_ref);
