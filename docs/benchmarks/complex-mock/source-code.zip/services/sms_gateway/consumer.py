"""Complete the event-driven delivery path."""
from services.sms_gateway.events import accept, publish
from services.sms_gateway.provider import deliver


def handle(envelope, bus, transport, logger):
    payload = accept(envelope)
    result = deliver(payload, transport)
    logger.info("delivery completed id=%s", envelope["id"])
    publish(bus, envelope["id"], {"status": "submitted"})
    return result
