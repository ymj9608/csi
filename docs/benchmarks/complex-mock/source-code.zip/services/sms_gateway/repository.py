"""Bound-parameter persistence for message_records; caller owns transaction."""


def save(db, record):
    db.execute(
        "INSERT INTO message_records (record_id, owner_ref, template_key, version) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(record_id) DO UPDATE SET template_key=excluded.template_key, version=version+1",
        (record.record_id, record.owner_ref, record.template_key, record.version),
    )


def find(db, record_id):
    return db.execute("SELECT * FROM message_records WHERE record_id = ?", (record_id,)).fetchone()


def for_owner(db, owner_ref):
    return db.execute("SELECT record_id, version FROM message_records WHERE owner_ref = ?", (owner_ref,)).fetchall()
